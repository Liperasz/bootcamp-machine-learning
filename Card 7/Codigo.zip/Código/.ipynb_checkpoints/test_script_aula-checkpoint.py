# arquivo utilizado para testar a execução via o comando 'python'
print('Hello viewers')